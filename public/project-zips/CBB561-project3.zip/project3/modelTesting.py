from keras.models import load_model
from utils import onehot, readfasta
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt



# William Skelly 

# Sim1 Testing

# sim1_test = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim1/test.fasta")
# sim1_Xtest, sim1_Ytest = onehot(sim1_test)

# model1 = load_model("sim1_model.keras")

# model1.summary()
# model1.evaluate(sim1_Xtest, sim1_Ytest)

# Sim2 Testing

sim2_test = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim2/test.fasta")

sim2_Xtest, sim2_Ytest = onehot(sim2_test)

model2 = load_model("sim2_model.keras")

model2.summary()
model2.evaluate(sim2_Xtest, sim2_Ytest)

# Sim6 Testing

# sim6_test = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim6/test.fasta")

# sim6_Xtest, sim6_Ytest = onehot(sim6_test)

# model6 = load_model("sim6_model_0.3.keras")

# model6.summary()
# model6.evaluate(sim6_Xtest, sim6_Ytest)

# Sim7 Testing

# sim7_test = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim7/test.fasta")

# sim7_Xtest, sim7_Ytest = onehot(sim7_test)

# model7 = load_model("sim7_model_0.3.keras")

# model7.summary()

# model7.evaluate(sim7_Xtest, sim7_Ytest)


# Build ROC Curve

# Get predicted probabilities on test set
y_pred_prob = model2.predict(sim2_Xtest)

# Compute ROC curve and AUC
fpr, tpr, thresholds = roc_curve(sim2_Ytest, y_pred_prob)
roc_auc = auc(fpr, tpr)

# Plot ROC Curve

plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='blue', lw=2, label=f'ROC curve (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], color='gray', lw=1, linestyle='--', label='Random Guessing')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc='lower right')
plt.grid(True)
plt.tight_layout()
plt.savefig('sim2_ROC.png', dpi = 300)
plt.show()


import numpy as np
import keras
from keras import layers
from keras import optimizers
from keras import losses 
from keras import metrics
from utils import onehot, readfasta

sim2_train = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim2/train.fasta")
sim2_validation = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim2/validation.fasta")

sim2_Xtrain, sim2_Ytrain = onehot(sim2_train)
sim2_Xval, sim2_Yval = onehot(sim2_validation)


# Anna Corcoran

# Model parameters
conv_filters = [64, 32]       
dense_units = [64, 32]
dropout_rate = 0.5
input_shape = (249, 4)

# Model building 
model = keras.Sequential()

model.add(layers.Input(shape=input_shape))

# Conv1D layers
for f in conv_filters:
    model.add(layers.Conv1D(filters=f, kernel_size=5, activation='relu'))
    model.add(layers.BatchNormalization())

model.add(layers.GlobalMaxPooling1D())  # Instead of Flatten (more efficient)

# Dense layers
for units in dense_units:
    model.add(layers.Dense(units, activation='relu'))
    model.add(layers.LayerNormalization())
    model.add(layers.Dropout(dropout_rate))

# Final output

model.add(layers.Dense(1, activation='sigmoid'))

opt = optimizers.Adam(learning_rate=1e-4)

model.compile(
    optimizer= opt,
    loss=losses.BinaryCrossentropy(),
    metrics=[metrics.BinaryAccuracy()]
)

model.summary()

# Model fitting 

model.fit(sim2_Xtrain, sim2_Ytrain, verbose=1,
validation_data=(sim2_Xval, sim2_Yval), 
batch_size= 128, epochs=50)

# Saving model 
model.save("sim2_model.keras")
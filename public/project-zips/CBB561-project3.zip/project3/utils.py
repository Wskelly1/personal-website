import numpy as np

# Anna Corcoran 
def readfasta(file):

    sequences = {}  # Dictionary to store sequence: label pairs
    current_sequence = []  # Temporary list to build multi-line sequences
    class_label = None  # Stores the current class label

    with open(file, "r") as seqs:
        for line in seqs:
            line = line.strip()
            if line.startswith(">"):  
                # If there's an existing sequence, store it before processing the new header
                if current_sequence and class_label:
                    full_sequence = "".join(current_sequence)
                    sequences[full_sequence] = class_label
                
                parts = line.split("/")  
                if len(parts) < 2:
                    class_label = None  # Reset if no valid label found
                else:
                    class_label = parts[1].split("=")[1].lower()  # Store class label
                
                # Reset sequence buffer for the next sequence
                current_sequence = []
            else:
                # Add sequence lines to buffer
                if class_label is not None:
                    current_sequence.append(line)
        
        # Store the last sequence after finishing reading the file
        if current_sequence and class_label:
            full_sequence = "".join(current_sequence)
            sequences[full_sequence] = class_label
    return sequences


# Anna Corcoran
def onehot(sequences):
    encodes = []
    
    maxlen = max(len(seq) for seq in sequences.keys())

    print(maxlen)
    X = np.zeros((len(sequences), maxlen, 4), dtype=np.float32)
    Y = np.zeros(len(sequences), dtype=np.int32)

    for i,  (seq, class_label) in enumerate(sequences.items()):
        for j, char in enumerate(seq):
            if char == "A":
                X[i, j] = [1,0,0,0]
            elif char == "C":
                X[i, j] = [0,1,0,0]
            elif char == "G":
                X[i, j] = [0,0,1,0]
            elif char == "T":
                X[i, j] = [0,0,0,1]
            else:
                X[i, j] = [0,0,0,0]
        Y[i] = class_label

       
    return X, Y
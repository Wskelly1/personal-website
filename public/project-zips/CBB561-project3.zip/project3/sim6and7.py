import numpy as np
import keras
from keras import layers
from keras import optimizers
from keras import losses 
from keras import metrics
from utils import onehot, readfasta
import matplotlib.pyplot as plt

sim6_train = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim6/train.fasta")
sim6_validation = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim6/validation.fasta")

sim7_train = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim7/train.fasta")
sim7_validation = readfasta("/hpc/group/coursess25/CS561-CS260/DATA/project3/sim7/validation.fasta")



sim6_Xtrain, sim6_Ytrain = onehot(sim6_train)
sim6_Xval, sim6_Yval = onehot(sim6_validation)

sim7_Xtrain, sim7_Ytrain = onehot(sim7_train)
sim7_Xval, sim7_Yval = onehot(sim7_validation)

# William Skelly

# Model parameters
dropout_rate = 0.3
input_shape = (249, 4)

# Model building 
inputs = layers.Input(shape=input_shape)

# Conv1D layers
x = layers.Conv1D(filters = 64, kernel_size = 15, padding = 'valid', activation = 'relu')(inputs)
x = layers.MaxPooling1D(pool_size = 5)(x)
x = layers.Dropout(rate=dropout_rate)(x)

# Conv block 2
x = layers.Conv1D(filters=128, kernel_size=5, padding='valid', activation='relu')(x)
x = layers.MaxPooling1D(pool_size=5)(x)
x = layers.Dropout(rate=dropout_rate)(x)

# Flatten and dense layers
x = layers.Flatten()(x)
x = layers.Dense(units=256, activation='relu')(x)
x = layers.Dropout(rate=dropout_rate)(x)
x = layers.Dense(units=64, activation='relu')(x)

# Output
outputs = layers.Dense(units=1, activation='sigmoid')(x)

model = keras.Model(inputs=inputs, outputs=outputs)

opt = optimizers.Adam(learning_rate=1e-4)

model.compile(
    optimizer= opt,
    loss=losses.BinaryCrossentropy(),
    metrics=[metrics.BinaryAccuracy()]
)

model.summary()

# Model fitting 

history = model.fit(sim6_Xtrain, sim6_Ytrain, verbose=1,
validation_data=(sim6_Xval, sim6_Yval), 
batch_size= 64, epochs=50)

# Saving model 
model.save("sim6_model_0.3.keras")


# Plot Validation and Training Accuracy 

plt.figure(figsize=(10, 6))
plt.plot(history.history['binary_accuracy'], label='Training Accuracy')
plt.plot(history.history['val_binary_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

plt.savefig('sim6_0.3.png', dpi=300)